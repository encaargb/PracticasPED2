# Hello World for the Unix shells (sh, ksh, csh, bash, ...)

echo 'Hello World!'
