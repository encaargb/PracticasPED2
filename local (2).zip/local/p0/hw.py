# Hello World in Python
print "Hello World!"
