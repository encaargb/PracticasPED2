# Hello World in Ruby
puts "Hello World!"
