# Hello World in Lua

print "Hello world"

