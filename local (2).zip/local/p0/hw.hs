-- Hello World in Haskell
 
main = putStrLn "Hello World"

